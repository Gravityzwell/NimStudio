This directory contains the test cases.
Each test must have a filename of the form: ``t*.nim``

Each test can contain a spec in a ``discard """"""`` block.

The folder ``rodfiles`` contains special tests that test incremental 
compilation via symbol files.

The folder ``dll`` contains simple DLL tests.

