The cross platform todo illustrates how to use Nim to create a backend
called by different native user interfaces.

This example builds on the knowledge learned from the cross_calculator example.
Check it out first to learn how to set up Nim on different platforms.
Additional implementations are provided at the external
https://github.com/gradha/nimrod-crossplatform-todo github repository.
