//+---------------------------------------------------------------------------

#include <windows.h>

BOOL WINAPI DllMain (HANDLE hDll, DWORD dwReason, LPVOID lpReserved)
{
	return TRUE;
}

